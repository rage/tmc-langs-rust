
public class Arith {
    public static int add(int a, int b) {
        return 7;
    }
    
        public static int sub(int a, int b) {
        return 0;
    }
    
    public static int mul(int a, int b) {
        return 0;
    }
    
    public static int div(int a, int b) {
        return 0;
    }
}
