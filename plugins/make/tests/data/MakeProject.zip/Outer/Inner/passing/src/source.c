#include <stdio.h>
#include "source.h"

int one(void)
{
  return 1;
}
