
public class Trivial {
    // Make this return 1 to make the test pass.
    public int f() {
        //BEGIN SOLUTION
        return 1;
        //END SOLUTION
        //STUB: return 0;
    }
}
