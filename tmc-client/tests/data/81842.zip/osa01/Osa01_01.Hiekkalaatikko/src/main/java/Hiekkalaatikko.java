
public class Hiekkalaatikko {

    public static void main(String[] args) {
        // Toteuta ohjelmasi tänne
    }
}
