
import fi.helsinki.cs.tmc.edutestutils.MockStdio;
import fi.helsinki.cs.tmc.edutestutils.Points;
import org.junit.*;

@Points("01-01")
public class HiekkalaatikkoTest {

    @Rule
    public MockStdio io = new MockStdio();

    @Test
    public void ilmaisetPisteet() {
    }

}
