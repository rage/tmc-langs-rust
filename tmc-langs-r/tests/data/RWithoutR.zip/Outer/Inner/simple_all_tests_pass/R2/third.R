ret_false <- function() {
  FALSE
}
