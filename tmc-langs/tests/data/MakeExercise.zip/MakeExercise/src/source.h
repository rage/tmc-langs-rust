int one(void);
